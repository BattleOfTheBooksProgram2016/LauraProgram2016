import java.util.ArrayList;

public class Book {

	private String bookTitle;
	private String bookAuthor;
	private String bookCover;
	private ArrayList<String> questions;
	
	public Book(){}
	public Book (String title, String author, String bookCover) {
		this.bookTitle = title;
		this.bookAuthor = author;
		this.bookCover = bookCover;
	}
	
	
	//getters and setters
	public String getBookTitle()
	{
		return this.bookTitle;
	}
	
	public void setBookTitle(String bookTitle)
	{
		this.bookTitle = bookTitle;
	}
	
	public String getBookAuthor()
	{
		return this.bookAuthor;
	}
	
	public void setBookAuthor(String bookAuthor)
	{
		this.bookAuthor = bookAuthor;
	}
	
	public String getBookCover()
	{
		return this.bookCover;
	}
	
	public void setBookCover(String bookCover)
	{
		this.bookCover = bookCover;
	}
	
	public ArrayList<String> getQuestions()
	{
		return questions;
	}
	
	public void setQuestions(ArrayList<String> questions)
	{
		this.questions = questions;
	}
	
	public void addQuestion(String question)
	{
		this.questions.add(question);
	}
	
}
