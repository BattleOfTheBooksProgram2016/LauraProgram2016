import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class Application {
	
	private Charset encoding = StandardCharsets.UTF_8;

	private final String bookTitles[] = {"The Wrath and the Dawn", "Anya's War", "Me and Earl and the Dying Girl", "Mosquitoland", "The Night Gardener", "Red Queen", "The Law of Loving Others", "The Hill", "Nowehere Wild", "The Witch Hunter", "Away Running", "The Scorpion Rules", "In the Time of Dragon Moon", "Sight Unseen", "Red Wolf", "Exquisite Captive", "Material Girls", "Salvage", "Court of Fives", "The Accident Season", "The Girl at Midnight", "In the Swish", "Magonia", "The Fire Horse Girl", "Girl Detective", "What We Hide", "Going Over", "Grandmaster", "The Art of Secrets", "The Art of Getting Stared At", "Under a Painted Sky", "The Fire Wish", "Egg and Spoon", "Vanishing Girls", "Anatomy of a Misfit", "Numbers", "Snow Like Ashes", "The Boy in the Black Suit", "The Bodies We Wear", "Bone Gap", "The Blackthorn Key", "Challenger Deep", "Are You Experienced", "The Walls Around Us", "The Dogs", "An Ember in the Ashes", "Trouble is a Friend of Mine", "Fire Colour One", "Like Water on Stone", "Black Dove, White Raven", "Afterworlds", "Diamond Boy", "The Cure for Dreaming", "Belzhar", "The Museum of Intangible Things"};
	
	private final String bookAuthors[] = {"Renee Ahdieh", "Andrea Alban", "Jesse Andrews", "David Arnold", "Jonathan Auxier", "Victoria Aveyard", "Kate Axelrod", "Karen Bass", "Joe Beernink", "Virginia Boecker", "Luc Bouchard and David Wright", "Erin Bow", "Janet Lee Carey", "David Carroll", "Jennifer Dance", "Heather Demetrios", "Elaine Dimopoulos", "Alexandra Duncan", "Kate Elliot", "Moira Fowley-Doyle", "Melissa Grey", "Dawn Green", "Maria Dahvana Headley", "Kay Honeyman", "Simmone Howell", "Marthe Jocelyn", "Beth Kephart", "Davis Klass", "James Klise", "Laura Langston", "Stacey Lee", "Amber Lough", "Gregory Maguire", "Lauren Oliver", "Andrea Portes", "David Poulsen", "Sara Raasch", "Jason Reynolds", "Jey Roberts", "Laura Ruby", "Kevin Sands", "Neal Shusterman", "Jordan Sonnenblick", "Nova Ren Suma", "Allan Stratton", "Sabaa Tahir", "Stephanie Tromly", "Jenny Valentine", "Dana Walrath", "Elizabeth Wein", "Scott Westerfeld", "Michael Williams", "Cat Winters", "Meg Wolitzer", "Wendy Wunder"};
	//book list
	//http://www.woozles.com/pdf/tbattle17.pdf
	
	private int indexOfBook[];
	
	private int questionsLeft;
	
	private String fileName;
		
	
	/*public void countBooks()
	{
		System.out.println(bookTitles.length);
		System.out.println(bookAuthors.length);
	}*/
	
	//getters and setters
	
	public String[] getBookTitles()
	{
		return this.bookTitles;
	}
	
	public int numberOfBooks()
	{
		return bookTitles.length;
	}
	
	public String getBookTitle(int index)
	{
		return this.bookTitles[index];
	}
	
	public String[] getBookAuthors()
	{
		return this.bookAuthors;
	}
	
	public String getBookAuthor(int index)
	{
		return this.bookAuthors[index];
	}
	
	
	
	
	//needed methods
	
	public boolean validateNumbers(String questionNumber)
	{
		for(int i=0; i<questionNumber.length(); i++)
		{
			char c = questionNumber.charAt(i);
			if(!Character.isDigit(c))
			{
				return false;
			}
		}
		
		int questions = (int) Double.parseDouble(questionNumber);
		
		if (questions < 5)
		{
			return false;
		}
		
		else if(questions >50)
		{
			return false;
		}
		else
		{
			indexOfBook = new int[questions];
			questionsLeft = questions;
			
			randomlySelectBooks();
			
			return true;
		}
	}
	
	public void saveQuestion(int bookIndex, String question)
	{
		fileName = bookTitles[bookIndex].toString()+".txt";
		
		readWriteTheQuestions(question);
		
	}
	
	private void randomlySelectBooks()
	{
		
		for (int i=0; i<indexOfBook.length; i++)
		{
			//Pick a book randomly between 0 and  numberOfBooks-1;
		}
		
	}
	
	
	
	
	
	//reading and writing text files
	
	public List<String> readWriteTheQuestions(String question)
	{
		//String writeReportFile = "src\\bookFiles\\"+fileName;
		List<String> bookQuestions= null;
		
		try 
		{
			bookQuestions = this.readQuestions();
			bookQuestions.add(question+"\n");
			//speciesAdd.add();
			//bookQuestions = this.readQuestions();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try 
		{
			this.writeQuestions(bookQuestions);
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bookQuestions;
	}
	
	//writing code
	private void writeQuestions(List<String>bookQuestions)throws IOException
	{
		Path path = Paths.get("src\\bookFiles\\"+fileName);
		Files.write(path, bookQuestions, encoding, StandardOpenOption.WRITE);
	}
	
	
	//reading code
	
	private List<String> readQuestions()throws IOException
	{
		Path path = Paths.get("src\\bookFiles\\"+fileName);
		return Files.readAllLines(path, encoding);
}
	
}
