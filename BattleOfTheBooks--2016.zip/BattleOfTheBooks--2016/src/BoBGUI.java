import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JComboBox;
//specially imported
import javax.swing.Timer;
import javax.swing.JOptionPane;

public class BoBGUI extends JFrame {

	Application app = new Application();
	
	final int INITIAL_DELAY = 20;
	//https://www.google.ca/?gws_rd=ssl#q=milliseconds+to+seconds for conversion
	//http://www.woozles.com/battle.php timer
	final int TIMER_DELAY = 1000;
	final int MAX_TIME = 90000;
	public int timeCount = 0;
	
	Timer timer = new Timer(TIMER_DELAY, new TimerHandler());
	
	private JPanel contentPane;
	private JTextField txttimeLeft;
	private JTextField txtAddQuestion;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BoBGUI frame = new BoBGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("unchecked")
	public BoBGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		
		//JPanels
		
		JPanel mainScreen = new JPanel();
		contentPane.add(mainScreen, "name_1057289443518165");
		mainScreen.setLayout(null);
		
		JPanel questions = new JPanel();
		contentPane.add(questions, "name_1057297498667884");
		questions.setLayout(null);
		
		JPanel answers = new JPanel();
		contentPane.add(answers, "name_1057320356488645");
		answers.setLayout(null);
		
		JPanel addQuestion = new JPanel();
		contentPane.add(addQuestion, "name_1057329529724298");
		addQuestion.setLayout(null);
		
		JPanel bookEdit = new JPanel();
		contentPane.add(bookEdit, "name_1162606354434607");
		bookEdit.setLayout(null);
		
		
		
		//JPanel Main screen
		
		JButton Battle = new JButton("Battle!");
		Battle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				while(true)
				{
					String numberOfQuestions = JOptionPane.showInputDialog(null, "How many questions would you like? (Between 5 and 50).", "Number of Questions", 1);
					if (app.validateNumbers(numberOfQuestions))
					{
						break;
					}
					JOptionPane.showMessageDialog(null, "Please enter the number of questions you would like. (Between 5 and 50).", "Enter numbers only", 0);
				}
				
				mainScreen.setVisible(false);
				questions.setVisible(true);
				
				timer.setInitialDelay(INITIAL_DELAY);
				timer.start();
				
			}
		});
		Battle.setBounds(155, 43, 120, 23);
		mainScreen.add(Battle);
		
		JButton btnAddQuestion = new JButton("Add Question");
		btnAddQuestion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainScreen.setVisible(false);
				addQuestion.setVisible(true);
			}
		});
		btnAddQuestion.setBounds(155, 109, 120, 23);
		mainScreen.add(btnAddQuestion);
		
		JButton btnJeopardy = new JButton("Jeopardy");
		btnJeopardy.setBounds(155, 149, 120, 23);
		btnJeopardy.setEnabled(false);
		mainScreen.add(btnJeopardy);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(EXIT_ON_CLOSE);
			}
		});
		btnExit.setBounds(155, 191, 120, 23);
		mainScreen.add(btnExit);
		
		JButton btnBooks = new JButton("Edit Books");
		btnBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				bookEdit.setVisible(true);
				mainScreen.setVisible(false);
				
			}
		});
		btnBooks.setBounds(155, 75, 120, 23);
		btnBooks.setEnabled(false);
		mainScreen.add(btnBooks);
		
		JComboBox cboYear = new JComboBox();
		cboYear.setBounds(341, 220, 73, 20);
		cboYear.setEnabled(false);
		mainScreen.add(cboYear);
		
		JLabel lblYear = new JLabel("Year:");
		lblYear.setBounds(299, 223, 46, 14);
		lblYear.setEnabled(false);
		mainScreen.add(lblYear);
		
		
		
		//JPanel Questions
		
		JLabel lblQuestion = new JLabel("Question: In which book is this statement true?");
		lblQuestion.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuestion.setBounds(10, 63, 414, 39);
		questions.add(lblQuestion);
		
		JLabel lblTimeLeft = new JLabel("Time Left:");
		lblTimeLeft.setBounds(10, 135, 66, 21);
		questions.add(lblTimeLeft);
		
		txttimeLeft = new JTextField();
		txttimeLeft.setEditable(false);
		txttimeLeft.setBounds(73, 135, 86, 20);
		questions.add(txttimeLeft);
		txttimeLeft.setColumns(10);
		
		JButton btnAnswer = new JButton("Answer");
		btnAnswer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				timer.stop();
				
				timeCount = 0;
				
				
				answers.setVisible(true);
				questions.setVisible(false);
				
			}
		});
		btnAnswer.setBounds(303, 134, 89, 23);
		questions.add(btnAnswer);
		
		
		
		
		//JPanel Answers
		
		//combo box
		JComboBox cboBookTitles = new JComboBox();
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				timer.restart();
				
				questions.setVisible(true);
				answers.setVisible(false);
			}
		});
		btnNext.setBounds(308, 217, 106, 23);
		answers.add(btnNext);
		
		JButton btnAnsMainMenu = new JButton("Main Menu");
		btnAnsMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				answers.setVisible(false);
				mainScreen.setVisible(true);
			}
		});
		btnAnsMainMenu.setBounds(10, 217, 106, 23);
		answers.add(btnAnsMainMenu);
		
		JLabel lblBookCoverAns = new JLabel("box");
		lblBookCoverAns.setBackground(Color.ORANGE);
		lblBookCoverAns.setBounds(10, 11, 128, 153);
		answers.add(lblBookCoverAns);
		
		JLabel lblAnswerTitle = new JLabel("Answer: Title");
		lblAnswerTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnswerTitle.setBounds(198, 37, 139, 23);
		answers.add(lblAnswerTitle);
		
		JLabel lblAnswerAuthor = new JLabel("By Author");
		lblAnswerAuthor.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnswerAuthor.setBounds(198, 64, 139, 23);
		answers.add(lblAnswerAuthor);
		
		JLabel lblAddQuestion = new JLabel("Question:");
		lblAddQuestion.setBounds(9, 169, 73, 22);
		addQuestion.add(lblAddQuestion);
		
		txtAddQuestion = new JTextField();
		txtAddQuestion.setToolTipText("Please add the question for the book selected, here.");
		txtAddQuestion.setBounds(92, 170, 297, 20);
		addQuestion.add(txtAddQuestion);
		txtAddQuestion.setColumns(10);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				app.saveQuestion(cboBookTitles.getSelectedIndex(), txtAddQuestion.getText());
				
				JOptionPane.showMessageDialog(null, "The question has been saved!", "Saved", 1);
				
				txtAddQuestion.setText("");
			}
		});
		btnSave.setBounds(307, 217, 107, 23);
		addQuestion.add(btnSave);
		
		JButton btnMainMenuAddQ = new JButton("Main Menu");
		btnMainMenuAddQ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addQuestion.setVisible(false);
				mainScreen.setVisible(true);
			}
		});
		btnMainMenuAddQ.setBounds(10, 217, 107, 23);
		addQuestion.add(btnMainMenuAddQ);
		
		JLabel lblAuthor = new JLabel("Author");
		lblAuthor.setText(app.getBookAuthor(0));
		lblAuthor.setHorizontalAlignment(SwingConstants.LEFT);
		lblAuthor.setBounds(146, 36, 243, 22);
		addQuestion.add(lblAuthor);
		
		JLabel lblSelectBook = new JLabel("Please select book:");
		lblSelectBook.setBounds(9, 104, 127, 22);
		addQuestion.add(lblSelectBook);
		
		//Combo box for the book titles
		cboBookTitles.setBounds(138, 105, 251, 20);
		addQuestion.add(cboBookTitles);
		cboBookTitles.setModel(new DefaultComboBoxModel(app.getBookTitles()));
		cboBookTitles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblAuthor.setText(app.getBookAuthor(cboBookTitles.getSelectedIndex()));
				
			}
		});
		
		
		
		
		
		
		
		//JPanel book edit
		
		JLabel lblbookYear = new JLabel("Year: ");
		lblbookYear.setBounds(10, 11, 46, 14);
		bookEdit.add(lblbookYear);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(83, 8, 114, 20);
		bookEdit.add(comboBox);
		
		JLabel lblBookEditTitle = new JLabel("Title: ");
		lblBookEditTitle.setBounds(10, 59, 46, 14);
		bookEdit.add(lblBookEditTitle);
		
		textField = new JTextField();
		textField.setBounds(83, 56, 186, 20);
		bookEdit.add(textField);
		textField.setColumns(10);
		
		JLabel lblBookEditAuthor = new JLabel("Author:");
		lblBookEditAuthor.setBounds(10, 99, 46, 14);
		bookEdit.add(lblBookEditAuthor);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(83, 96, 186, 20);
		bookEdit.add(textField_1);
		
		JLabel lblBookEditCover = new JLabel("Image Name:");
		lblBookEditCover.setBounds(10, 143, 76, 14);
		bookEdit.add(lblBookEditCover);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(83, 140, 186, 20);
		bookEdit.add(textField_2);
		
		//adding the save button above
		JButton btnSaveBookEdit = new JButton("Save");
		
		JButton btnTest = new JButton("Test");
		btnTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				btnSaveBookEdit.setEnabled(true);
				btnTest.setEnabled(false);
				
			}
		});
		btnTest.setBounds(325, 217, 89, 23);
		bookEdit.add(btnTest);
		
		//save button on the book edit
		btnSaveBookEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSaveBookEdit.setBounds(109, 217, 89, 23);
		btnSaveBookEdit.setEnabled(false);
		bookEdit.add(btnSaveBookEdit);
		
		JButton btnMainMenu = new JButton("Main Menu");
		btnMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mainScreen.setVisible(true);
				bookEdit.setVisible(false);
				
			}
		});
		btnMainMenu.setBounds(10, 217, 89, 23);
		bookEdit.add(btnMainMenu);
		
		JLabel lblBookCoverImage = new JLabel("book cover image");
		lblBookCoverImage.setBounds(279, 11, 135, 164);
		bookEdit.add(lblBookCoverImage);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnEdit.setBounds(219, 217, 89, 23);
		btnEdit.setEnabled(false);
		bookEdit.add(btnEdit);
	}
	
	//timer
	
	//inner class
	public class TimerHandler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Autogenerated method stub
			
			
			if (timeCount == MAX_TIME)
			{
				JOptionPane.showMessageDialog(null, "The time is done!", "Timer is done", 1);
				
				timeCount = 0;
				
				timer.stop();
			}
			
			else if (((MAX_TIME - timeCount) / 1000) >= 60)
			{
				int secondsLeft = ((MAX_TIME - timeCount) / 1000) - 60;
				txttimeLeft.setText("1."+secondsLeft);
				
				timeCount = timeCount + 1000;
			}
			
			else
			{
				Number timeLeft = (MAX_TIME- timeCount) / 1000;
				
				txttimeLeft.setText(timeLeft.toString());
				
				timeCount = timeCount + 1000;
				
			}
			
		}
		
	}
}
